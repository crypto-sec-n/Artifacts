export interface TorConfig {
  host: string
  port: number
  password: string
}
