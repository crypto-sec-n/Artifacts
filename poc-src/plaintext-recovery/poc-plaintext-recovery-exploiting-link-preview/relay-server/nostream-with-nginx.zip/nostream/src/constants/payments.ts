export enum FeeSchedules {
  ADMISSION = 'admission',
  PUBLICATION = 'publication'
}
