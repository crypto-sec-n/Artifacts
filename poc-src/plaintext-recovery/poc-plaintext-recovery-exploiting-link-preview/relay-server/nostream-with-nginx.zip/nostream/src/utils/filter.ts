export const isGenericTagQuery = (key: string) => /^#[a-z]$/.test(key)
